const tbody = document.getElementById('bodyRubrica')
rendertable();
function rendertable() {
    fetch('http://localhost:3000/posts')
        .then((response) => response.json())
        .then((data) => {
            data.forEach(element => {


                const tr = document.createElement('tr')

                const tdNome = document.createElement('td')
                const tdCognome = document.createElement('td')
                const tdTelefono = document.createElement('td')
                const tdModElimina = document.createElement('td')
                const tdButtonModifica = document.createElement('button')
                const tdButtonElimina = document.createElement('button')
                tdButtonModifica.addEventListener("click", () => Modifica(element.id));
                

                tbody.appendChild(tr)
                tr.appendChild(tdNome)
                tr.appendChild(tdCognome)
                tr.appendChild(tdTelefono)
                tr.appendChild(tdModElimina)
                tdModElimina.appendChild(tdButtonModifica)
                tdModElimina.appendChild(tdButtonElimina)
                
                tdButtonModifica.classList.add('btn')
                tdButtonModifica.classList.add('btn-warning')
                
                tdButtonElimina.classList.add('btn')
                tdButtonElimina.classList.add('btn-danger')


                tdNome.innerHTML = element.Nome
                tdCognome.innerHTML = element.Cognome
                tdTelefono.innerHTML = element.Telefono

                tdButtonModifica.innerHTML = "Modifica"
                tdButtonElimina.innerHTML = "Elimina"
            });
        });
}

    function AddPersona() {
        rendertable();
        // const Nome = document.getElementById("Nome");
        // const Cognome = document.getElementById("Cognome");
        // const Telefono = document.getElementById("Telefono");
        
        let persona = {
          Nome: "test",
          Cognome: "test",
          Telefono: "test"
        };
      
        fetch("http://localhost:3000/posts", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(persona),
        });
      
        titolo.value = "";
        autore.value = "";
        testo.value = "";
        immagine.value = "";
      }

      AddPersona();
      
      function Modifica(id) {
        rendertable();
        // const Nome = document.getElementById("Nome");
        // const Cognome = document.getElementById("Cognome");
        // const Telefono = document.getElementById("Telefono");
        
        let persona = {
            Nome: "test",
            Cognome: "test",
            Telefono: "test"
        //   Nome: Nome.value,
        //   Cognome: Cognome.value,
        //   Telefono: Telefono.value
        };
      
        fetch("http://localhost:3000/posts", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(persona),
        });
      
        titolo.value = "";
        autore.value = "";
        testo.value = "";
        immagine.value = "";
        console.log(id);
      }